
import { TrendingUp, Target, Calendar } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';

const monthlyData = [
  { month: 'Jan', amount: 1200 },
  { month: 'Feb', amount: 1350 },
  { month: 'Mar', amount: 980 },
  { month: 'Apr', amount: 1180 },
  { month: 'May', amount: 1420 },
  { month: 'Jun', amount: 1234 },
];

const categoryTrends = [
  { month: 'Jan', groceries: 400, dining: 200, gas: 150, shopping: 300, entertainment: 150 },
  { month: 'Feb', groceries: 450, dining: 250, gas: 180, shopping: 320, entertainment: 150 },
  { month: 'Mar', groceries: 380, dining: 180, gas: 120, shopping: 200, entertainment: 100 },
  { month: 'Apr', groceries: 420, dining: 220, gas: 160, shopping: 280, entertainment: 100 },
  { month: 'May', groceries: 480, dining: 280, gas: 200, shopping: 350, entertainment: 110 },
  { month: 'Jun', groceries: 457, dining: 289, gas: 157, shopping: 234, entertainment: 97 },
];

const MonthlyOverview = () => {
  const budgetGoal = 1500;
  const currentSpend = 1234;
  const percentOfBudget = (currentSpend / budgetGoal) * 100;

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Monthly Overview</h1>
        <p className="text-gray-600">Track your spending trends and budget goals</p>
      </div>

      {/* Budget Goal Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="w-5 h-5" />
            Budget Progress
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-2xl font-bold">${currentSpend.toFixed(2)}</p>
                <p className="text-gray-600">of ${budgetGoal.toFixed(2)} budget</p>
              </div>
              <div className="text-right">
                <p className={`text-lg font-semibold ${percentOfBudget > 90 ? 'text-red-600' : percentOfBudget > 75 ? 'text-yellow-600' : 'text-green-600'}`}>
                  {percentOfBudget.toFixed(1)}%
                </p>
                <p className="text-gray-600">used</p>
              </div>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div 
                className={`h-3 rounded-full transition-all ${
                  percentOfBudget > 90 ? 'bg-red-500' : 
                  percentOfBudget > 75 ? 'bg-yellow-500' : 'bg-green-500'
                }`}
                style={{ width: `${Math.min(percentOfBudget, 100)}%` }}
              ></div>
            </div>
            <p className="text-sm text-gray-600">
              ${(budgetGoal - currentSpend).toFixed(2)} remaining this month
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Monthly Spending Trend */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            Monthly Spending Trend
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip formatter={(value) => [`$${value}`, 'Amount']} />
                <Bar dataKey="amount" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Category Comparison */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            Category Trends
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={categoryTrends}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="groceries" stroke="#22c55e" strokeWidth={2} name="Groceries" />
                <Line type="monotone" dataKey="dining" stroke="#f59e0b" strokeWidth={2} name="Dining" />
                <Line type="monotone" dataKey="gas" stroke="#ef4444" strokeWidth={2} name="Gas" />
                <Line type="monotone" dataKey="shopping" stroke="#8b5cf6" strokeWidth={2} name="Shopping" />
                <Line type="monotone" dataKey="entertainment" stroke="#06b6d4" strokeWidth={2} name="Entertainment" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="text-center">
              <p className="text-2xl font-bold text-green-600">$420</p>
              <p className="text-gray-600">Lowest Month</p>
              <p className="text-sm text-gray-500">March 2024</p>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="text-center">
              <p className="text-2xl font-bold text-red-600">$1,420</p>
              <p className="text-gray-600">Highest Month</p>
              <p className="text-sm text-gray-500">May 2024</p>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="text-center">
              <p className="text-2xl font-bold text-blue-600">$1,227</p>
              <p className="text-gray-600">Average Month</p>
              <p className="text-sm text-gray-500">6 month avg</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default MonthlyOverview;
