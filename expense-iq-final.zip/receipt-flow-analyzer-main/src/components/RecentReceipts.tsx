
import { Calendar, DollarSign, Store } from 'lucide-react';

const recentReceipts = [
  {
    id: 1,
    merchant: 'Whole Foods',
    amount: 89.32,
    date: '2024-06-18',
    category: 'Groceries',
    color: 'bg-green-100 text-green-800'
  },
  {
    id: 2,
    merchant: 'Shell Gas Station',
    amount: 45.67,
    date: '2024-06-17',
    category: 'Gas',
    color: 'bg-red-100 text-red-800'
  },
  {
    id: 3,
    merchant: 'Olive Garden',
    amount: 67.89,
    date: '2024-06-16',
    category: 'Dining',
    color: 'bg-yellow-100 text-yellow-800'
  },
  {
    id: 4,
    merchant: 'Target',
    amount: 123.45,
    date: '2024-06-15',
    category: 'Shopping',
    color: 'bg-purple-100 text-purple-800'
  }
];

const RecentReceipts = () => {
  return (
    <div className="space-y-3">
      {recentReceipts.map((receipt) => (
        <div key={receipt.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-white rounded-full">
              <Store className="w-4 h-4 text-gray-600" />
            </div>
            <div>
              <p className="font-medium text-gray-900">{receipt.merchant}</p>
              <div className="flex items-center space-x-4 text-sm text-gray-500">
                <span className="flex items-center">
                  <Calendar className="w-3 h-3 mr-1" />
                  {receipt.date}
                </span>
                <span className={`px-2 py-1 rounded-full text-xs ${receipt.color}`}>
                  {receipt.category}
                </span>
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-1 font-semibold text-gray-900">
            <DollarSign className="w-4 h-4" />
            <span>{receipt.amount}</span>
          </div>
        </div>
      ))}
    </div>
  );
};

export default RecentReceipts;
